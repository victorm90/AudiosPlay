# Simple Email HTML

A Pen created on CodePen.io. Original URL: [https://codepen.io/JoshBeard/pen/JeNKee](https://codepen.io/JoshBeard/pen/JeNKee).

Raw HTML for Email, before using Inline CSS tool.

From Lee Monroe "Responsive HTML Email Template"
(https://raw.githubusercontent.com/leemunroe/responsive-html-email-template/master/email.html)

CodePen for Inlined Email HTML: https://codepen.io/JoshBeardJB/pen/Mzmbog